# Banking Customer Analytics Dashboard | Power BI

A Power BI dashboard project exploring banking transactions, customer demographics, customer segmentation, and profitability/risk indicators.

## Dashboard Preview

### 1. Transaction Behavior
Analyzes transaction values and volume, trends over time, transaction activity by hour and weekday, and average transaction amount across age groups.

![Transaction Behavior Dashboard](screenshots/transaction-behavior.jpeg)

### 2. Customer Segmentation
Shows customer distribution by segment, revenue by segment, transaction frequency, average revenue per customer, age-group distribution, and RFM score distribution.

![Customer Segmentation Dashboard](screenshots/customer-segmentation.jpeg)

### 3. Profitability & Risk
Summarizes transaction activity, monetary value, average revenue per customer, and customer-segment comparisons for active, lost, and new customers.

![Profitability and Risk Dashboard](screenshots/profitability-and-risk.jpeg)

### 4. Customer Demographics
Presents customer counts, average age, unique locations, gender and age-group distributions, customer details, and geographic distribution.

![Customer Demographics Dashboard](screenshots/customer-demographics.jpeg)

## Tools
- Microsoft Power BI
- Power Query for data preparation
- DAX for measures and KPIs (where applicable)
- Data visualization and interactive filtering

## Project Focus
- Transaction behavior and time-based patterns
- Customer segmentation and engagement
- Revenue and monetary-value comparisons
- Customer demographics and location analysis

## Repository Contents
```text
banking-customer-analytics-github/
├── README.md
└── screenshots/
    ├── transaction-behavior.jpeg
    ├── customer-segmentation.jpeg
    ├── profitability-and-risk.jpeg
    └── customer-demographics.jpeg
```

> Note: The dashboard screenshots are included as provided; the dashboard visuals have not been edited.
